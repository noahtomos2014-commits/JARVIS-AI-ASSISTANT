# JARVIS Personal AI

A working Node.js/Express assistant starter with a dark sci-fi dashboard, browser microphone input, browser text-to-speech, AI chat, SQLite conversation history and user-managed memories.

## Requirements
- Node.js 20+
- An OpenAI-compatible API key and model
- Optional Tavily API key for internet search

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set `AI_API_KEY` and, if needed, `AI_BASE_URL` and `AI_MODEL`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

The microphone requires browser permission and a secure context (localhost is accepted). Speech recognition availability depends on the browser. Text chat works without a microphone.

## Render deployment
1. Push this folder to a GitHub repository.
2. In Render, create a **Web Service** connected to that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables from `.env.example`, especially `AI_API_KEY`, `AI_MODEL`, `AI_BASE_URL`, and a long random `JARVIS_API_TOKEN`.
6. Set `NODE_ENV=production`.
7. Set `FRONTEND_ORIGIN` to the deployed origin if serving the included UI elsewhere.
8. Deploy.

**Persistence:** SQLite is suitable for a single persistent disk. On Render, attach a persistent disk and set `DATABASE_PATH` to a path on that disk (for example `/var/data/jarvis.sqlite`). Without a persistent disk, local SQLite data may be lost on redeploy/restart. For multiple instances, migrate the database adapter to PostgreSQL.

## API
All API routes accept `x-jarvis-token` when `JARVIS_API_TOKEN` is configured.

- `POST /api/chat` — `{ "message": "...", "conversationId": "..." }`
- `POST /api/voice/process` — `{ "text": "...", "conversationId": "..." }` for an external speech-to-text provider; included browser UI currently sends recognised speech to `/api/chat`.
- `POST /api/commands/execute` — `{ "command": "time" }`; supported commands: `time`, `search`, `repeat`.
- `GET /api/status` — backend, AI configuration, search and database status.
- `GET /api/health` — basic health check.
- `GET /api/memory` — list saved memories.
- `POST /api/memory` — `{ "content": "..." }`.
- `DELETE /api/memory/:id` — delete a memory.

## Frontend integration
The included UI is in `public/`. It calls the JSON API using `fetch`. If you replace it with your own supplied HUD, preserve the endpoint contracts above. Add the API token as the `x-jarvis-token` header if token protection is enabled. The included dashboard has working text chat, browser speech recognition, speech synthesis, memory controls, quick time command and live health polling.

## Security notes
- Never put provider keys in browser code or commit `.env`.
- Set `JARVIS_API_TOKEN` before exposing the service publicly.
- Configure `FRONTEND_ORIGIN` to trusted origins.
- Commands are allow-listed; no arbitrary shell/code execution is provided.
- Consequential integrations (email, smart home, file access, etc.) should be added as separately permissioned tools with confirmation.
- The built-in memory feature stores only text the user explicitly adds. Conversation history is stored in SQLite.
- Web search requires `TAVILY_API_KEY`; no search is fabricated when it is absent.

## Current boundaries
- Browser speech-to-text is browser-dependent (typically Chrome-based browsers); it is not a server-side transcription engine.
- Browser speech synthesis uses voices installed/provided by the browser.
- AI provider connection is only testable after you supply a valid key.
- SQLite is implemented. PostgreSQL support is a future adapter, not enabled in this starter.
- This project does not yet implement authentication accounts, WebSocket streaming, or autonomous actions.
