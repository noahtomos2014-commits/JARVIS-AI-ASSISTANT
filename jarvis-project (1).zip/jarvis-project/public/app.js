const $ = id => document.getElementById(id);
let conversationId = crypto.randomUUID ? crypto.randomUUID() : String(Date.now());
let voiceEnabled = true, recognition = null, listening = false, busy = false;
const token = () => localStorage.getItem("jarvisToken") || "";
async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", "x-jarvis-token": token(), ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function setState(state) {
  $("chatState").textContent = state.toUpperCase();
  $("coreState").textContent = state.toUpperCase();
  $("mainSubtitle").textContent = ({ listening:"I'm listening.", thinking:"Processing your request.", speaking:"Speaking response.", error:"An issue needs your attention.", idle:"Your assistant is ready when you are." })[state] || "Your assistant is ready.";
}
function addMessage(role, content) {
  const el = document.createElement("div");
  el.className = `message ${role}`;
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = role === "assistant" ? "J" : "Y";
  const body = document.createElement("div");
  const label = document.createElement("label"); label.textContent = role === "assistant" ? "JARVIS" : "YOU";
  const time = document.createElement("time"); time.textContent = new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}); label.append(" ", time);
  const p = document.createElement("p"); p.textContent = content;
  body.append(label,p); el.append(avatar,body); $("messages").append(el); $("messages").scrollTop = $("messages").scrollHeight;
}
function speak(text) {
  if (!voiceEnabled || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.96; utterance.pitch = 0.92; utterance.volume = 1;
  utterance.onstart = () => setState("speaking");
  utterance.onend = () => setState("idle");
  utterance.onerror = () => setState("idle");
  speechSynthesis.speak(utterance);
}
async function sendMessage(text) {
  if (busy || !text.trim()) return;
  busy = true; $("sendBtn").disabled = true; addMessage("user",text); $("messageInput").value = ""; setState("thinking");
  try {
    const data = await api("/chat",{method:"POST",body:JSON.stringify({message:text,conversationId})});
    addMessage("assistant",data.response); speak(data.response); if (!speechSynthesis.speaking) setState("idle");
  } catch (e) { addMessage("assistant",`I couldn't complete that request: ${e.message}`); setState("error"); }
  finally { busy=false; $("sendBtn").disabled=false; }
}
$("sendBtn").addEventListener("click",()=>sendMessage($("messageInput").value));
$("messageInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage(e.target.value)}});
$("stopVoice").addEventListener("click",()=>{if("speechSynthesis"in window)speechSynthesis.cancel();setState("idle")});
$("speakToggle").addEventListener("click",()=>{voiceEnabled=!voiceEnabled;$("speakToggle").textContent=voiceEnabled?"VOICE ON":"VOICE OFF";if(!voiceEnabled)speechSynthesis.cancel()});
$("newChat").addEventListener("click",()=>{conversationId=crypto.randomUUID?crypto.randomUUID():String(Date.now());$("messages").replaceChildren();setState("idle");addMessage("assistant","New session ready. How can I help?")});
$("clearChat").addEventListener("click",()=>{$("messages").replaceChildren();addMessage("assistant","Conversation cleared from this view. Stored history remains in the database.")});
$("micBtn").addEventListener("click",()=>{
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){$("micNote").textContent="Speech recognition is not supported here. Please use the text box.";return}
  if(listening){recognition.stop();return}
  recognition=new SR();recognition.lang=navigator.language||"en-GB";recognition.interimResults=true;recognition.continuous=false;
  recognition.onstart=()=>{listening=true;$("micBtn").innerHTML="<span>■</span> STOP LISTENING";$("voiceState").textContent="LISTENING";setState("listening")};
  recognition.onresult=e=>{let finalText="", interim="";for(let i=e.resultIndex;i<e.results.length;i++){if(e.results[i].isFinal)finalText+=e.results[i][0].transcript;else interim+=e.results[i][0].transcript}$("messageInput").value=finalText||interim;if(finalText.trim())sendMessage(finalText.trim())};
  recognition.onerror=e=>{$("micNote").textContent=`Microphone issue: ${e.error}. Check browser permissions.`};
  recognition.onend=()=>{listening=false;$("micBtn").innerHTML="<span>🎙</span> ACTIVATE VOICE";$("voiceState").textContent="VOICE READY";if($("chatState").textContent==="LISTENING")setState("idle")};
  try{recognition.start()}catch(e){$("micNote").textContent="Unable to start microphone. Try again."}
});
document.querySelectorAll("[data-command]").forEach(btn=>btn.addEventListener("click",async()=>{
  try{const d=await api("/commands/execute",{method:"POST",body:JSON.stringify({command:btn.dataset.command})});addMessage("assistant",d.result.message||JSON.stringify(d.result))}catch(e){addMessage("assistant",e.message)}
}));
$("settingsBtn").addEventListener("click",()=>{$("tokenInput").value=token();$("settingsDialog").showModal()});
$("saveToken").addEventListener("click",e=>{e.preventDefault();localStorage.setItem("jarvisToken",$("tokenInput").value.trim());$("settingsDialog").close();refreshStatus()});
$("memoryBtn").addEventListener("click",async()=>{await loadMemories();$("memoryDialog").showModal()});
async function loadMemories(){try{const d=await api("/memory");$("memoryList").replaceChildren();d.memories.forEach(m=>{const row=document.createElement("div"),span=document.createElement("span"),del=document.createElement("button");span.textContent=m.content;del.textContent="DELETE";del.onclick=async()=>{await api(`/memory/${m.id}`,{method:"DELETE"});loadMemories()};row.append(span,del);$("memoryList").append(row)})}catch(e){$("memoryList").textContent=e.message}}
$("saveMemory").addEventListener("click",async e=>{e.preventDefault();const content=$("memoryInput").value.trim();if(!content)return;try{await api("/memory",{method:"POST",body:JSON.stringify({content})});$("memoryInput").value="";loadMemories()}catch(err){$("memoryList").textContent=err.message}});
async function refreshStatus(){try{const s=await api("/status");$("connection").textContent="BACKEND CONNECTED";$("backendStatus").textContent="ONLINE";$("aiStatus").textContent=s.aiConfigured?"CONFIGURED":"ADD API KEY";$("aiStatus").className=s.aiConfigured?"":"offline";$("dbStatus").textContent=s.database.toUpperCase();$("ttsStatus").textContent=("speechSynthesis"in window)?"AVAILABLE":"UNAVAILABLE";$("modelName").textContent=s.model;$("searchStatus").textContent=s.searchConfigured?"ENABLED":"DISABLED"}catch(e){$("connection").textContent="DISCONNECTED";$("backendStatus").textContent="OFFLINE";$("backendStatus").className="offline";$("aiStatus").textContent="UNAVAILABLE";$("dbStatus").textContent="UNKNOWN"}}
function clock(){ $("clock").textContent=new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"}) }
clock();setInterval(clock,1000);refreshStatus();setInterval(refreshStatus,30000);
