const { searchWeb } = require("../search/webSearch");
const { logAction } = require("../services/logger");

const commands = {
  time: async () => ({ message: `The current server time is ${new Date().toLocaleString()}.` }),
  search: async ({ query }) => {
    if (!query || typeof query !== "string" || query.length > 500) throw Object.assign(new Error("Provide a search query under 500 characters."), { status: 400 });
    const results = await searchWeb(query);
    logAction("web_search", { query });
    return { results };
  },
  repeat: async ({ text }) => ({ message: typeof text === "string" ? text.slice(0, 4000) : "There is no previous response to repeat." })
};
module.exports = { commands };
