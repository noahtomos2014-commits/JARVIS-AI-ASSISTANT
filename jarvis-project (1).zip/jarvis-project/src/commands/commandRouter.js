const { commands } = require("./commandRegistry");
async function execute(name, args = {}) {
  const handler = commands[name];
  if (!handler) throw Object.assign(new Error("That command is not available."), { status: 400 });
  return handler(args);
}
module.exports = { execute };
