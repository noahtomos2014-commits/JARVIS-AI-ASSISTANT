const router = require("express").Router();
const { database } = require("../memory/database");
router.get("/", (_req, res) => {
  let databaseOk = false;
  try { database().prepare("SELECT 1").get(); databaseOk = true; } catch {}
  res.json({
    backend: "online",
    aiConfigured: Boolean(process.env.AI_API_KEY),
    searchConfigured: Boolean(process.env.TAVILY_API_KEY),
    database: databaseOk ? "online" : "offline",
    speechRecognition: "browser-dependent",
    speechSynthesis: "browser-dependent",
    model: process.env.AI_MODEL || "gpt-4o-mini",
    timestamp: new Date().toISOString()
  });
});
module.exports = router;
