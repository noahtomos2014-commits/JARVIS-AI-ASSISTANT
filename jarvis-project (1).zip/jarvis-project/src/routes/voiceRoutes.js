const router = require("express").Router();
const { chat } = require("../ai/aiEngine");
const { saveMessage, getHistory } = require("../memory/memoryManager");
router.post("/process", async (req, res, next) => {
  try {
    const { text, conversationId = "default" } = req.body || {};
    if (typeof text !== "string" || !text.trim() || text.length > 12000) return res.status(400).json({ error: "Recognised speech is empty or too long." });
    const id = String(conversationId).slice(0, 100);
    saveMessage(id, "user", text.trim());
    const response = await chat(getHistory(id, 20));
    saveMessage(id, "assistant", response);
    res.json({ transcript: text.trim(), response, state: "idle" });
  } catch (err) { next(err); }
});
module.exports = router;
