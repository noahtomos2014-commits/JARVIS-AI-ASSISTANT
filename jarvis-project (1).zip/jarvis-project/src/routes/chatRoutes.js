const router = require("express").Router();
const { chat } = require("../ai/aiEngine");
const { saveMessage, getHistory, listMemories } = require("../memory/memoryManager");

router.post("/", async (req, res, next) => {
  try {
    const { message, conversationId = "default" } = req.body || {};
    if (typeof message !== "string" || !message.trim() || message.length > 12000) {
      return res.status(400).json({ error: "Message must be between 1 and 12,000 characters." });
    }
    const id = String(conversationId).slice(0, 100);
    saveMessage(id, "user", message.trim());
    const history = getHistory(id, 20);
    const memories = listMemories().slice(0, 10).map(m => ({ role: "system", content: `User-approved memory: ${m.content}` }));
    const response = await chat([...memories, ...history]);
    saveMessage(id, "assistant", response);
    res.json({ response, conversationId: id, state: "idle" });
  } catch (err) { next(err); }
});
module.exports = router;
