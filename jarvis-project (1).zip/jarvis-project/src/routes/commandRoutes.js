const router = require("express").Router();
const { execute } = require("../commands/commandRouter");
router.post("/execute", async (req, res, next) => {
  try {
    const { command, args } = req.body || {};
    const result = await execute(command, args);
    res.json({ ok: true, result });
  } catch (err) { next(err); }
});
module.exports = router;
