const router = require("express").Router();
const { listMemories, addMemory, deleteMemory } = require("../memory/memoryManager");
router.get("/", (_req, res) => res.json({ memories: listMemories() }));
router.post("/", (req, res) => {
  const { content } = req.body || {};
  if (typeof content !== "string" || !content.trim() || content.length > 2000) return res.status(400).json({ error: "Memory must be between 1 and 2,000 characters." });
  res.status(201).json({ id: addMemory(content.trim()), content: content.trim() });
});
router.delete("/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid memory ID." });
  if (!deleteMemory(id)) return res.status(404).json({ error: "Memory not found." });
  res.json({ ok: true });
});
module.exports = router;
