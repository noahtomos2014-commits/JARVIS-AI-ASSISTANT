const settings = require("../config/settings");
const systemPrompt = require("./systemPrompt");

async function chat(messages) {
  if (!process.env.AI_API_KEY) {
    const error = new Error("AI is not configured. Add AI_API_KEY to your Render environment variables.");
    error.status = 503;
    throw error;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), settings.aiTimeoutMs);
  try {
    const base = settings.aiBaseUrl.replace(/\/$/, "");
    const response = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.AI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: settings.aiModel,
        messages: [{ role: "system", content: systemPrompt }, ...messages],
        max_tokens: settings.aiMaxTokens,
        temperature: 0.7
      }),
      signal: controller.signal
    });
    if (!response.ok) {
      const body = await response.text();
      const error = new Error(`AI provider returned ${response.status}: ${body.slice(0, 300)}`);
      error.status = response.status === 429 ? 429 : 502;
      throw error;
    }
    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    if (typeof content !== "string" || !content.trim()) throw new Error("AI provider returned an empty response.");
    return content.trim();
  } catch (err) {
    if (err.name === "AbortError") {
      const timeout = new Error("The AI provider took too long to respond.");
      timeout.status = 504;
      throw timeout;
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}
module.exports = { chat };
