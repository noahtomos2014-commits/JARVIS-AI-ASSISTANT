function errorHandler(err, _req, res, _next) {
  console.error("[JARVIS]", err && err.message ? err.message : err);
  const status = Number(err.status) || 500;
  res.status(status).json({
    error: status >= 500 ? "JARVIS encountered an internal error." : err.message,
    ...(process.env.NODE_ENV !== "production" ? { detail: err.message } : {})
  });
}
module.exports = { errorHandler };
