function logAction(action, details = {}) {
  console.log(JSON.stringify({ at: new Date().toISOString(), action, details }));
}
module.exports = { logAction };
