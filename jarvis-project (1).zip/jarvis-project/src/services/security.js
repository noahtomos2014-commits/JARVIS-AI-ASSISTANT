const rateLimit = require("express-rate-limit");

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 60,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please wait a moment." }
});

function requireApiToken(req, res, next) {
  const expected = process.env.JARVIS_API_TOKEN;
  if (!expected) {
    if (process.env.NODE_ENV === "production") {
      return res.status(503).json({ error: "Set JARVIS_API_TOKEN before public deployment." });
    }
    return next();
  }
  const supplied = req.get("x-jarvis-token");
  if (!supplied || supplied !== expected) return res.status(401).json({ error: "Unauthorised. Check your JARVIS access token." });
  next();
}

module.exports = { apiLimiter, requireApiToken };
