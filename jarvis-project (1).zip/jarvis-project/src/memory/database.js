const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

let db;
function initDatabase() {
  if (db) return db;
  const filename = path.resolve(process.env.DATABASE_PATH || "./data/jarvis.sqlite");
  fs.mkdirSync(path.dirname(filename), { recursive: true });
  db = new Database(filename);
  db.pragma("journal_mode = WAL");
  db.exec(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversation_id TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('user','assistant')),
      content TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, id);
    CREATE TABLE IF NOT EXISTS memories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);
  return db;
}
function database() { return db || initDatabase(); }
module.exports = { initDatabase, database };
