const { database } = require("./database");
function saveMessage(conversationId, role, content) {
  database().prepare("INSERT INTO messages (conversation_id, role, content) VALUES (?, ?, ?)").run(conversationId, role, content);
}
function getHistory(conversationId, limit = 20) {
  return database().prepare("SELECT role, content FROM messages WHERE conversation_id = ? ORDER BY id DESC LIMIT ?")
    .all(conversationId, limit).reverse();
}
function listMemories() {
  return database().prepare("SELECT id, content, created_at FROM memories ORDER BY id DESC").all();
}
function addMemory(content) {
  return database().prepare("INSERT INTO memories (content) VALUES (?)").run(content).lastInsertRowid;
}
function deleteMemory(id) {
  return database().prepare("DELETE FROM memories WHERE id = ?").run(id).changes > 0;
}
module.exports = { saveMessage, getHistory, listMemories, addMemory, deleteMemory };
