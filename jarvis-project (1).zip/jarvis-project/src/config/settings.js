module.exports = {
  aiBaseUrl: process.env.AI_BASE_URL || "https://api.openai.com/v1",
  aiModel: process.env.AI_MODEL || "gpt-4o-mini",
  aiTimeoutMs: Number(process.env.AI_TIMEOUT_MS) || 45000,
  aiMaxTokens: Number(process.env.AI_MAX_TOKENS) || 900
};
