async function searchWeb(query) {
  if (!process.env.TAVILY_API_KEY) {
    const error = new Error("Web search is not configured. Add TAVILY_API_KEY to enable it.");
    error.status = 503;
    throw error;
  }
  const response = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ api_key: process.env.TAVILY_API_KEY, query, max_results: 5 })
  });
  if (!response.ok) throw new Error(`Search provider returned ${response.status}`);
  const data = await response.json();
  return (data.results || []).map(r => ({ title: r.title, url: r.url, content: r.content }));
}
module.exports = { searchWeb };
